<?php
ob_start();
include_once "lib/Database.php";
include_once "helpers/Format.php";

spl_autoload_register(function($class_name) {
    include_once 'classes/' . $class_name . ".php";
});
$common = new Common();

if (Session::get("login") == false) {
	header("Location: login.php");
}


$customer_id = Session::get('customerId');
$customer_name = Session::get('customerName');
$total_amount = Session::get('grand_total');

if (isset($_GET['id']) && $_GET['id'] != '') {
	$transaction_id = $_GET['id'];
	$payment_details = $common->select("`payment`", "`transaction_id` = '$transaction_id'");
	if ($payment_details) {
		$payment_detail = mysqli_fetch_assoc($payment_details);
	} else {
		header("Location: index.php");
	}
} else {
	header("Location: index.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Order Successful</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

	<div class="container py-5">
		<div class="row">
			<div class="col-md-6 offset-md-3">
				<p class="font-italic">Support: 01700000000</p>
				<div class="card">
					<div class="card-header bg-primary text-white">
					    <h5 class="mb-0">
					   		Order Placed Successfully
						</h5>
					</div>
				  	<div class="card-body">
				    	<table class="table table-bordered">
						  <tbody>
						    <tr>
						      <td>Customer Name</td>
						      <td><?= $customer_name; ?></td>
						    </tr>
						    <tr>
						      <td>Merchant ID</td>
						      <td>rashidkhan35</td>
						    </tr>
						    <tr>
						      <td>Transaction ID</td>
						      <td><?= $transaction_id; ?></td>
						    </tr>
						    <tr>
						      <td>Total Amount</td>
						      <td>
						      	<b><?= $total_amount; ?>/=BDT</b>
						      </td>
						    </tr>
						    <tr>
						      <td colspan="2">
						      	<p class="text-center">Check your <a href="order.php">Order</a>.</p>
						      </td>
						    </tr>
						  </tbody>
						</table>
				  	</div>
				</div>
			</div>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

</body>
</html>