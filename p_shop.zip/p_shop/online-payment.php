<?php
ob_start();
include_once "lib/Database.php";
include_once "helpers/Format.php";

spl_autoload_register(function($class_name) {
    include_once 'classes/' . $class_name . ".php";
});
$database = new Database();
$format = new Format();
$cart = new Cart();
$common = new Common();

if (Session::get("login") == false) {
	header("Location: login.php");
}

$customer_id = Session::get('customerId');
$customer_name = Session::get('customerName');
$total_amount = Session::get('grand_total');

$marchant_id = '1';
$marchant = 'Fahim Dewan';

if($total_amount == 0) {
	header("Location: index.php");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['card_pay'])) {
	$type = 'card';
	$card_number = $_POST['card_number'];
	$mm_yy = $_POST['mm_yy'];
	$cvc_cvv = $_POST['cvc_cvv'];
	$card_owner = $_POST['card_owner'];

	$transaction_id = uniqid() . time();

	$insert = $common->insert("`payment`(`marchant`, `customer_id`, `transaction_id`, `amount`, `type`, `card_number`, `mm_yy`, `cvc_cvv`, `card_owner`)", "('$marchant_id', '$customer_id', '$transaction_id', '$total_amount', '$type', '$card_number', '$mm_yy', '$cvc_cvv', '$card_owner')");
	if ($insert) {
		$cart->insertOrder();
		$cart->deleteCartBySession();
		header("Location: success.php?id=" . $transaction_id);
	} else {
		$failed = '<div class="alert alert-danger mt-2">Something is wrong!</div>';
	}
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['mobile_pay'])) {
	$type = $_POST['type'];
	$number = $_POST['number'];

	$transaction_id = uniqid() . time();

	$insert = $common->insert("`payment`(`customer_id`, `transaction_id`, `amount`, `type`, `number`)", "('$customer_id', '$transaction_id', '$total_amount', '$type', '$number')");
	if ($insert) {
		$cart->insertOrder();
		$cart->deleteCartBySession();
		header("Location: success.php?id=" . $transaction_id);
	} else {
		$failed = '<div class="alert alert-danger mt-2">Something is wrong!</div>';
	}
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['bank_pay'])) {
	$type = $_POST['type'];
	$account_number = $_POST['account_number'];
	$branch = $_POST['branch'];

	$transaction_id = uniqid() . time();

	$insert = $common->insert("`payment`(`customer_id`, `transaction_id`, `amount`, `type`, `account_number`, `branch_name`)", "('$customer_id', '$transaction_id', '$total_amount', '$type', '$account_number', '$branch')");
	if ($insert) {
		$cart->insertOrder();
		$cart->deleteCartBySession();
		header("Location: success.php?id=" . $transaction_id);
	} else {
		$failed = '<div class="alert alert-danger mt-2">Something is wrong!</div>';
	}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Online Payment</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

	<div class="container py-5">
		<p class="font-italic">Support: 01700000000</p>
		<div class="row">
			<div class="col-md-5">
				<div class="card">
					<div class="card-header bg-primary text-white">
					    <h5 class="mb-0">
					    	<i class="fas fa-shopping-cart mr-2"></i>
					   		Your Order Summary
						</h5>
					</div>
				  	<div class="card-body">
				    	<table class="table table-bordered">
						  <tbody>
						    <tr>
						      <td>Customer Name</td>
						      <td><?= $customer_name; ?></td>
						    </tr>
						    <tr>
						      <td>Merchant ID</td>
						      <td><?= $marchant; ?></td>
						    </tr>
						    <tr>
						      <td>Total Amount</td>
						      <td>
						      	<b><?= $total_amount; ?>/=BDT</b>
						      </td>
						    </tr>
						    <tr>
						      <td colspan="2">
						      	<a href="cart.php" class="btn btn-danger float-right">Cancel</a>
						      </td>
						    </tr>
						  </tbody>
						</table>
				  	</div>
				</div>
				<?= isset($failed) ? $failed : ''; ?>
			</div>
			<div class="col-md-7">
				<div class="card">
					<div class="card-header bg-primary text-white">
					    <h5 class="mb-0">
					    	<i class="fas fa-money-check mr-2"></i>
					    	Select Payment Method
					    </h5>
					</div>
				  	<div class="card-body">
				    	<ul class="nav nav-tabs" id="myTab" role="tablist">
						  <li class="nav-item" role="presentation">
						    <button class="nav-link active" id="card-tab" data-toggle="tab" data-target="#card" type="button" role="tab" aria-controls="card" aria-selected="true">Card</button>
						  </li>
						  <li class="nav-item" role="presentation">
						    <button class="nav-link" id="mobile-tab" data-toggle="tab" data-target="#mobile" type="button" role="tab" aria-controls="mobile" aria-selected="false">Mobile Banking</button>
						  </li>
						  <li class="nav-item" role="presentation">
						    <button class="nav-link" id="bank-tab" data-toggle="tab" data-target="#bank" type="button" role="tab" aria-controls="bank" aria-selected="false">Internet Banking</button>
						  </li>
						</ul>
						<div class="tab-content" id="myTabContent">
						  <div class="tab-pane fade show active" id="card" role="tabpanel" aria-labelledby="card-tab">
						  	<div id="card_part" class="mt-3">
						  		<img src="images/payment/visa-card.png" width="35" alt="Visa Card">
						  		<img src="images/payment/mastercard.png" width="35" alt="Master Card">
						  		<form action="" method="POST" class="mt-2">
						  			<input class="form-control mb-3" type="text" pattern="[0-9]{16}" name="card_number" placeholder="Card Number" required>
						  			<div class="form-row">
									    <div class="col mb-3">
									      <input type="number" class="form-control" name="mm_yy" placeholder="MM/YY" pattern="[0-9]{4}" required>
									    </div>
									    <div class="col">
									      <input type="number" class="form-control" name="cvc_cvv" placeholder="CVC/CVV" pattern="[0-9]{3}" required>
									    </div>
									</div>
								  <input class="form-control mb-3" type="text" name="card_owner" placeholder="Card Owner Name" required>
								  <button type="submit" class="btn btn-primary w-100" name="card_pay">Pay Now</button>
						  		</form>
						  	</div>
						  </div>
						  <div class="tab-pane fade" id="mobile" role="tabpanel" aria-labelledby="mobile-tab">
						  	<div id="mobile_part" class="mt-3">
						  		<div onclick="mobile_part('bkash')" class="d-inline-block pr-3">
						  			<img src="images/payment/bkash.png" style="width: 120px; height: 80px; cursor: pointer;" alt="Ibbl">
						  		</div>
						  		<div onclick="mobile_part('nagad')" class="d-inline-block pr-3">
						  			<img src="images/payment/nagad.png" style="width: 120px; height: 80px; cursor: pointer;" alt="Ibbl">
						  		</div>
						  		<div onclick="mobile_part('rocket')" class="d-inline-block pr-3">
						  			<img src="images/payment/dbblmobilebank.png" style="width: 120px; height: 120px; cursor: pointer;" alt="Ibbl">
						  		</div>
						  	</div>
						  </div>
						  <div class="tab-pane fade" id="bank" role="tabpanel" aria-labelledby="bank-tab">
						  	<div id="bank_part" class="mt-3">
						  		<div onclick="internet_banking('islami')" class="d-inline-block pr-3">
						  			<img src="images/payment/ibbl.png" style="width: 120px; cursor: pointer;" alt="Ibbl">
						  		</div>
						  		<div onclick="internet_banking('city')" class="d-inline-block pr-3">
						  			<img src="images/payment/citytouch.png" style="width: 120px; cursor: pointer;" alt="Ibbl">
						  		</div>
						  		<div onclick="internet_banking('asia')" class="d-inline-block pr-3">
						  			<img src="images/payment/bankasia.png" style="width: 120px; cursor: pointer;" alt="Ibbl">
						  		</div>
						  	</div>
						  </div>
						</div>
				  	</div>
				</div>
			</div>
		</div>
	</div>

	<!-- mobile banking modal start -->
	<div class="modal fade" id="mobile_banking" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="staticBackdropLabel">
	        	Mobile Banking
	        </h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	      	<div class="text-center mb-3">
	      		<img id="mobile_image" src="" style="width: 120px; height: 80px;" alt="Image">
	      	</div>
	        <form action="" method="POST">
	        	<input type="hidden" name="type" id="mobile_type">
	        	<input class="form-control mb-3" type="tel" name="number" placeholder="Your Number" required>
	        	<input class="form-control mb-3" type="tel" name="password" placeholder="Your Password" required>
	        	<input type="submit" class="btn btn-primary mb-3 w-100" name="mobile_pay" value="Pay Now">
	        </form>
	      </div>
	    </div>
	  </div>
	</div>
	<!-- mobile banking modal end -->

	<!-- internet banking modal start -->
	<div class="modal fade" id="internet_banking" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="staticBackdropLabel">
	        	Internet Banking
	        </h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	      	<div class="text-center mb-3">
	      		<img id="bank_image" src="" style="width: 120px;" alt="Image">
	      	</div>
	        <form action="" method="POST">
	        	<input type="hidden" name="type" id="bank_type">
	        	<input class="form-control mb-3" type="number" name="account_number" placeholder="Account Number" required>
	        	<input class="form-control mb-3" type="text" name="branch" placeholder="Branch Name" required>
	        	<input type="submit" class="btn btn-primary mb-3 w-100" name="bank_pay" value="Pay Now">
	        </form>
	      </div>
	    </div>
	  </div>
	</div>
	<!-- internet banking modal end -->

	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

	<script>
		function mobile_part(value) {
			$('#mobile_type').val(value);
			if(value == 'bkash') {
				$('#mobile_image').attr("src", 'http://localhost/p_shop/images/payment/bkash.png');
			} else if(value == 'nagad') {
				$('#mobile_image').attr("src", 'http://localhost/p_shop/images/payment/nagad.png');
			} else if(value == 'rocket') {
				$('#mobile_image').attr("src", 'http://localhost/p_shop/images/payment/dbblmobilebank.png');
			}
			$('#mobile_banking').modal('show');
		}
		function internet_banking(value) {
			$('#bank_type').val(value);
			if(value == 'islami') {
				$('#bank_image').attr("src", 'http://localhost/p_shop/images/payment/ibbl.png');
			} else if(value == 'city') {
				$('#bank_image').attr("src", 'http://localhost/p_shop/images/payment/citytouch.png');
			} else if(value == 'asia') {
				$('#bank_image').attr("src", 'http://localhost/p_shop/images/payment/bankasia.png');
			}
			$('#internet_banking').modal('show');
		}
	</script>

</body>
</html>